import re
from collections import Counter

SQLI = re.compile(r"\bunion\s+select\b|;\s*(drop|delete|insert|update)\b", re.I)
XSS = re.compile(r"<\s*script\b|javascript\s*:", re.I)

def detect_event(event):
    alerts = []
    ip = str(event.get("source_ip", "unknown"))
    text = f"{event.get('path', '')} {event.get('message', '')}"
    status = str(event.get("status", "")).lower()
    if status in {"failed", "401", "403"}:
        alerts.append({"type": "FAILED_LOGIN", "severity": "medium", "source_ip": ip,
                       "details": "Failed login attempt"})
    if SQLI.search(text):
        alerts.append({"type": "SQL_INJECTION", "severity": "high", "source_ip": ip,
                       "details": "Possible SQL injection pattern"})
    if XSS.search(text):
        alerts.append({"type": "XSS", "severity": "high", "source_ip": ip,
                       "details": "Possible cross-site scripting pattern"})
    ports = event.get("ports", [])
    if isinstance(ports, list) and len(set(ports)) >= 5:
        alerts.append({"type": "PORT_SCAN", "severity": "high", "source_ip": ip,
                       "details": f"{len(set(ports))} unique ports in one event"})
    rpm = event.get("requests_per_minute", 0)
    if isinstance(rpm, (int, float)) and rpm >= 100:
        alerts.append({"type": "REQUEST_FLOOD", "severity": "high", "source_ip": ip,
                       "details": f"High request rate: {rpm}/minute"})
    return alerts

def detect_brute_force(events, threshold=5):
    counts = Counter(str(e.get("source_ip", "unknown")) for e in events
                     if str(e.get("status", "")).lower() in {"failed", "401", "403"})
    return [{"type": "BRUTE_FORCE", "severity": "high", "source_ip": ip,
             "details": f"{count} failed login attempts in submitted batch"}
            for ip, count in counts.items() if count >= threshold]
