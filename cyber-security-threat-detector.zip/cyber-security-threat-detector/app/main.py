import csv, io
from typing import Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.detector import detect_event, detect_brute_force

app = FastAPI(title="Cyber Security Threat Detector", version="1.0.0",
              description="Rule-based log analysis demo API.")

class AnalyzeRequest(BaseModel):
    events: list[dict[str, Any]] = Field(default_factory=list)

@app.get("/")
def root():
    return {"name": "Cyber Security Threat Detector", "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    alerts = [alert for event in request.events for alert in detect_event(event)]
    alerts.extend(detect_brute_force(request.events))
    return {"events_analyzed": len(request.events), "alert_count": len(alerts), "alerts": alerts}

@app.post("/analyze-csv")
def analyze_csv(csv_text: str):
    try:
        rows = list(csv.DictReader(io.StringIO(csv_text)))
    except csv.Error as exc:
        raise HTTPException(status_code=400, detail="Invalid CSV") from exc
    alerts = [alert for row in rows for alert in detect_event(row)]
    alerts.extend(detect_brute_force(rows))
    return {"events_analyzed": len(rows), "alert_count": len(alerts), "alerts": alerts}
