# Cyber Security Threat Detector

A Python + FastAPI demo that checks log events for suspicious patterns and returns alerts through a REST API.

## Detection rules
- **Brute force:** 5 or more failed logins from the same IP in one submitted batch.
- **SQL injection:** detects common patterns such as `UNION SELECT`.
- **XSS:** detects script tags and `javascript:` patterns.
- **Port scan:** flags an event listing 5 or more unique ports.
- **Request flood:** flags a reported rate of 100 or more requests per minute.
- **Failed login:** flags individual failed logins.

This is a learning project, not production security software. Rules can produce false positives or miss attacks. Use fictional/sample logs and do not expose sensitive logs through a public deployment.

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs to test the API.

## Example request
POST to `/analyze`:

```json
{
  "events": [
    {"source_ip":"192.0.2.20","username":"admin","status":"failed","path":"/login"},
    {"source_ip":"192.0.2.30","path":"/search?q=<script>alert(1)</script>"}
  ]
}
```

`sample_logs.json` contains fictional events. Copy its `events` array into the `/analyze` request.

## Tests
```bash
pytest
```

## Docker
```bash
docker build -t threat-detector .
docker run --rm -p 8000:8000 threat-detector
```

## Files
- `app/detector.py` — detection rules
- `app/main.py` — FastAPI endpoints
- `tests/` — basic automated tests
- `sample_logs.json` — fictional sample events
- `Dockerfile` — container setup

## Upload to GitHub
1. Extract this ZIP.
2. Create a repository named `cyber-security-threat-detector`.
3. Select **Add file → Upload files** and upload the extracted files/folders.
4. Commit the changes.

Or use Git in the extracted folder:
```bash
git init
git add .
git commit -m "Initial threat detector project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/cyber-security-threat-detector.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.
