from app.detector import detect_event, detect_brute_force

def test_sql_injection():
    assert any(a["type"] == "SQL_INJECTION" for a in detect_event(
        {"source_ip": "192.0.2.1", "path": "/items?id=1 UNION SELECT password"}))

def test_xss():
    assert any(a["type"] == "XSS" for a in detect_event(
        {"source_ip": "192.0.2.2", "message": "<script>alert(1)</script>"}))

def test_brute_force():
    events = [{"source_ip": "192.0.2.3", "status": "failed"} for _ in range(5)]
    assert any(a["type"] == "BRUTE_FORCE" for a in detect_brute_force(events))

def test_normal_event():
    assert detect_event({"source_ip": "192.0.2.4", "status": "200", "path": "/home"}) == []
